package com.cda.kursi.mynewbmiapplication;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.os.UserHandle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import org.w3c.dom.UserDataHandler;

/**
 * Created by kursi on 3/20/2016.
 */
public class CalculateBmi extends Activity{
    EditText h1,w1;
    TextView ans;
    String user_height, user_weight;
    Button bmi, save;
    Context ctx = this;
   // int status = 0;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.displaybmi);
        bmi = (Button) findViewById(R.id.btnbm);
        //save = (Button) findViewById(R.id.btnsave);

        ans = (TextView) findViewById(R.id.textView2);
        h1= (EditText) findViewById(R.id.editText3);
        w1= (EditText) findViewById(R.id.editText4);
        bmi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (  ( !h1.getText().toString().equals("")) && ( !w1.getText().toString().equals(""))) {
                    Double a, b, c;
                    a = Double.parseDouble(h1.getText().toString());
                    b = Double.parseDouble(w1.getText().toString());
                    user_height = a.toString();
                    user_weight = b.toString();
                    c = b / (a * a);
                    ans.setText(" " + c);
                    Database db = new Database(ctx);
                    db.putInformation(db, user_height, user_weight);
                    Toast.makeText(getBaseContext(),"Data Saved", Toast.LENGTH_LONG).show();
                    finish();
                }
            }    });
//        save.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                status = 1;
//                Bundle b = new Bundle();
//                b.putInt("status", status);
//                Intent i = new Intent("");
//                i.putExtras(b);
//                startActivity(i);
//
//                int status = b.getInt("status");
//                if(status == 1)
//                {
//                    Toast.makeText(getBaseContext(), "Please wait...", Toast.LENGTH_LONG).show();
//                    user_height = h1.getText().toString();
//                    user_weight = w1.getText().toString();
//                    Database dba = new Database(ctx);
//                    Cursor cr = dba.getInformation(dba);
//                    cr.moveToFirst();
//                    boolean loginstatus = false;
//                    String Height = "";
//                    String Weight = "";
//                    do{
//                        loginstatus = true;
//                        Height = cr.getString(0);
//                        Weight = cr.getString(1);
//
//
//                    }while(cr.moveToNext());
//                    if(loginstatus)
//                    {
//                        Toast.makeText(getBaseContext(), "Height "+Height + "Weight "+Weight, Toast.LENGTH_LONG).show();
//                        finish();
//                    }
//                    else
//                    {
//                        Toast.makeText(getBaseContext(), "No record exists", Toast.LENGTH_LONG).show();
//                        finish();
//                    }
//                }

//                String he,we;
//                he = "";
//                we = "";
//                UserHandle = new UserDataHandler(getBaseContext());
//                UserHandle.open();
//                Cursor c = UserHandle.returnData();
//                if(c.moveToFirst())
//                {
//                    do{
//                        he = c.getString(0);
//                        we = c.getString(1);
//
//                    }while(c.moveToNext());
//                }UserHandle.close();
//                Toast.makeText(getBaseContext(),"Height :"+he + "And Weight :"+we,Toast.LENGTH_LONG).show();
//            }
//        });
    }}




