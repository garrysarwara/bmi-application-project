package com.cda.kursi.mynewbmiapplication;

import android.provider.BaseColumns;

/**
 * Created by kursi on 3/31/2016.
 */
public class TableData {

    public TableData()
    {

    }

    public static abstract class TableInfo implements BaseColumns
    {

        public static final String user_height = "height";
        public static final String user_weight = "weight";
        public static final String Database_name = "user_info";
        public static final String TABLE_NAME = "reg_info";
    }
}
