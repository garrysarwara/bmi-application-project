package com.cda.kursi.mynewbmiapplication;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    //EditText uname,pass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button btn = (Button) findViewById(R.id.btnlogin);
        //uname= (EditText) findViewById(R.id.editText1);
        //pass= (EditText) findViewById(R.id.editText2);
//        public void methodtoCall(View view) {
//            Intent intent = new Intent(this, CalculateBmi.class);
//            startActivity(intent);
//            Button btn = (Button) findViewById(R.id.btnlogin);
//
//        }
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), CalculateBmi.class);
                startActivityForResult(intent, 0);
            }
        });
    }}
        //Button btn = (Button) findViewById(R.id.btnlogin);
//        InclassDatabase helper = new InclassDatabase(this);
//        SQLiteDatabase db = helper.getWritableDatabase();
//        btn.setOnClickListener(new View.OnClickListener(){
//          public void onClick(View v) {
//                Intent intent1 = new Intent(v.getContext(), CalculateBmi.class);
//                startActivityForResult(intent1, 0);
//            }});
//        Cursor cursor = db.query(InclassDatabase.TABLE_NAME, new String[]{"NAME", "PASSWORD"}, null, null, null, null, null);
//        if (cursor.moveToFirst()) {
//            String name = cursor.getString(0);
//            EditText results = (EditText) findViewById(R.id.editText1);
//            results.setText(name);
//        }
//        cursor.close();
//        db.close();
//    }

