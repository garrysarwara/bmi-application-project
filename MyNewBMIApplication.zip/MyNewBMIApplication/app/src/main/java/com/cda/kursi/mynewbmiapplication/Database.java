package com.cda.kursi.mynewbmiapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.TextView;

/**
 * Created by kursi on 3/31/2016.
 */
public class Database extends SQLiteOpenHelper{
public static final int database_version = 1;
    public String  CREATE_QUERY = "CREATE TABLE "+ TableData.TableInfo.TABLE_NAME+"("+ TableData.TableInfo.user_height+" TEXT,"+ TableData.TableInfo.user_weight+" TEXT );";
    //public String CREATE_QUERY1 = "SELECT * FROM "+ TableData.TableInfo.TABLE_NAME;
    public Database(Context context){
        super(context, TableData.TableInfo.Database_name, null, database_version);
        Log.d("Database operations", "One row inserted");

    }
//    public Cursor getInformation(Database dba)
//    {
//        SQLiteDatabase sql = dba.getReadableDatabase();
//        String[] columns = {TableData.TableInfo.user_height, TableData.TableInfo.user_weight};
//        Cursor cr = sql.query(TableData.TableInfo.TABLE_NAME, columns, null, null, null, null, null);
//        return cr;
//
//    }

    public void onCreate(SQLiteDatabase sdb) {

        sdb.execSQL(CREATE_QUERY);
        //sdb.execSQL(CREATE_QUERY1);

    }
    public void onUpgrade(SQLiteDatabase arg0, int arg1,int arg2)
    {

    }

        public void putInformation(Database d,String h,String w)
    {
        SQLiteDatabase sq = d.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(TableData.TableInfo.user_height, h);
        cv.put(TableData.TableInfo.user_weight, w);
        long k = sq.insert(TableData.TableInfo.TABLE_NAME, null, cv);
        Log.d("Database operations", "One row inserted");

    }

}
